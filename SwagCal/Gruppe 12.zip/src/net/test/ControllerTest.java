package net.test;

public interface ControllerTest {

	public void messageReceived(String s);
	
	public void sendMessage(String s);
	
}
