package gui;

import javax.swing.JFrame;

public class ServerGUI extends JFrame{

}