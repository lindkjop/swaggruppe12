package gui.actions;

public class AddPersonToPersonList {

}
